package com.example.nikolaservisnaknjizica;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Podaci extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.podaci_o_vozilu);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.Podaci), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        AppDatabase db=AppDatabase.getDatabase(getApplicationContext());

        EditText editTextMarka=findViewById(R.id.editTextMarka);
        EditText editTextModel=findViewById(R.id.editTextModel);
        EditText editTextNumber=findViewById(R.id.editTextNumberGod);
        EditText editTextKaroserija=findViewById(R.id.editTextKaroserija);
        EditText editTextGorivo=findViewById(R.id.editTextGorivo);
        EditText editTextSasija=findViewById(R.id.editTextSasija);
        EditText editTextkubikaza=findViewById(R.id.editTextNumberKubikaza);
        EditText editTextKilometraza=findViewById(R.id.editTextKilometraza);
        Button buttonVozilo=findViewById(R.id.buttonVozilo);
        TextView textViewPoruka=findViewById(R.id.textViewPoruka);

        buttonVozilo.setOnClickListener(v-> {
            String marka=editTextMarka.getText().toString().trim();
            String model=editTextModel.getText().toString().trim();
            String godiste=editTextNumber.getText().toString().trim();

            // Provera polja
            if (marka.isEmpty() || model.isEmpty() || godiste.isEmpty()){
                textViewPoruka.setText("Molimo unesite podatke");
            } else {
                // Kreiranje objekta
                Automobil noviAuto = new Automobil(
                        marka, model, godiste,
                        editTextKaroserija.getText().toString().trim(),
                        editTextGorivo.getText().toString().trim(),
                        editTextSasija.getText().toString().trim(),
                        editTextkubikaza.getText().toString().trim(),
                        editTextKilometraza.getText().toString().trim()
                );
                new Thread(() -> {
                    // Upisujemo u bazu
                    db.automobilDao().insertAuto(noviAuto);

                    // Vraćamo se na UI  da promenimo ekran
                    runOnUiThread(() -> {
                        Intent intent=new Intent(Podaci.this, Garaza.class);
                        intent.putExtra("AUTO", noviAuto);
                        startActivity(intent);
                        finish(); // Opciono: zatvara ovaj ekran da se korisnik ne vraća na praznu formu
                    });
                }).start();
            }
        });
    }
}