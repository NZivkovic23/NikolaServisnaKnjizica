package com.example.nikolaservisnaknjizica;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Povezivanje elemenata
        TextView textViewNaslov=findViewById(R.id.textViewNaslov);
        ImageView imageViewPocetna=findViewById(R.id.imageViewpocetna);
        TextView textViewPrijava=findViewById(R.id.textViewPrijava);
        TextView textViewUvod=findViewById(R.id.textViewUvod);
        TextView textViewEmail=findViewById(R.id.textViewEmail);
        TextView textViewPassword=findViewById(R.id.textViewPassword);
        EditText editTextEmail=findViewById(R.id.editTextEmail);
        EditText editTextPassword=findViewById(R.id.editTextPassword);
        Button buttonPrijava=findViewById(R.id.buttonPrijava);
        TextView textViewMessage=findViewById(R.id.textViewMessage);

        buttonPrijava.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextEmail.getText().toString().trim().isEmpty()) {
                    textViewMessage.setText("Molim vas unesite email");
                } else if (editTextPassword.getText().toString().trim().isEmpty()) {
                    textViewMessage.setText("Molim vas unesite password");

                } else {
                    Intent intent = new Intent(MainActivity.this, Garaza.class);
                    //Pokreni aktivnost
                    startActivity(intent);
                }
            }
        });


    }
    }