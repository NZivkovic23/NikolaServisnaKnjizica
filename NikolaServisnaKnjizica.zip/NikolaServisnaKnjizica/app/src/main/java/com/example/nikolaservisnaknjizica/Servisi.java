package com.example.nikolaservisnaknjizica;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.ArrayList;
import java.util.List;

public class Servisi extends AppCompatActivity {
    private Automobil auto;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.servisi);

        // Preuzimanje auta (objekta) - provera da li je stigao
        auto=(Automobil) getIntent().getSerializableExtra("AUTO");
        if (auto == null) {
            finish();
            return;
        }
        listView = findViewById(R.id.listViewServis);
        Button buttonDodavanjeServisa=findViewById(R.id.buttonDodavanjeServisa);
        Button buttonGaraza=findViewById(R.id.buttonGaraza);


        buttonDodavanjeServisa.setOnClickListener(v -> {
            Intent intent=new Intent(Servisi.this, Uradjeno.class);
            intent.putExtra("AUTO", auto);
            startActivity(intent);
        });

        buttonGaraza.setOnClickListener(v -> {
            Intent intent=new Intent(Servisi.this, Garaza.class);
            startActivity(intent);
            });

    }

   @Override
  protected void onResume() {
      super.onResume();
        // Osvežavamo listu svaki put kad se korisnik vrati iz klase "Uradjeno"
     ucitajServise();
    }

    private void ucitajServise() {
        new Thread(() -> {
            try {
                AppDatabase db=AppDatabase.getDatabase(getApplicationContext());
                // Tražimo servise po ID-ju automobila
                List<Service> lista=db.automobilDao().getServisiZaAuto(auto.id);

                ArrayList<String> opisi=new ArrayList<>();
                for (Service s : lista) {
                    opisi.add(s.opis);
                }

                // Ažuriranje interfejsa mora ići na UI
                runOnUiThread(() -> {
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(
                            Servisi.this,
                            android.R.layout.simple_list_item_1,
                            opisi
                    );
                    listView.setAdapter(adapter);
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}