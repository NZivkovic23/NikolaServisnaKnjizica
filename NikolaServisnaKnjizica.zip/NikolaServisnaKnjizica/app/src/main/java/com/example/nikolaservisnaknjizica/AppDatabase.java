package com.example.nikolaservisnaknjizica;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

//Definišemo koje tabele idu u bazu i verziju
@Database(entities = {Automobil.class, Service.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    //Povezujemo DAO interfejs
    public abstract AutomobilDao automobilDao();

    // Kreiramo Singleton instancu
    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "servisna_knjizica_db").fallbackToDestructiveMigration().build();
                    // Briše staru bazu ako promenimo verziju
                }
            }
        }
        return INSTANCE;
    }
}
