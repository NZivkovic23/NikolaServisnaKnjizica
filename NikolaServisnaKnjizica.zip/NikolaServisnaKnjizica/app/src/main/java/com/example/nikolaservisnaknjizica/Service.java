package com.example.nikolaservisnaknjizica;

import androidx.room.Entity;

import androidx.room.PrimaryKey;

@Entity(tableName = "servisi_tabela")
public class Service {
    @PrimaryKey(autoGenerate = true) public int servisId;
    public int autoId; // Povezuje servis sa ID-jem automobila
    public String opis;

    public Service(int autoId, String opis) {
        this.autoId = autoId;
        this.opis = opis;
    }
}
