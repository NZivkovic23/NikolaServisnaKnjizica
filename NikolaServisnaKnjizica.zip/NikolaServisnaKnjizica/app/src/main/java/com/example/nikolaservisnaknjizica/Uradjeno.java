package com.example.nikolaservisnaknjizica;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
public class Uradjeno extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.uradjeni_servisi);

        CheckBox checkBoxMaliServis=findViewById(R.id.checkBoxMaliServis);
        CheckBox checkBoxVelikiServis=findViewById(R.id.checkBoxVelikiServis);
        CheckBox checkBoxKlima=findViewById(R.id.checkBoxKlima);
        CheckBox checkBoxReglaza=findViewById(R.id.checkBoxReglaza);
        CheckBox checkBoxMenjac=findViewById(R.id.checkBoxMenjac);
        CheckBox checkBoxVulkanizer=findViewById(R.id.checkBoxVulkanizer);
        EditText editTextZamena=findViewById(R.id.editTextZamena);
        EditText editTextKilometraza=findViewById(R.id.editTextKilometraza);
        EditText editTextDatum=findViewById(R.id.editTextDatum);
        Button buttonServis=findViewById(R.id.buttonServis);
        TextView textViewObavestenje=findViewById(R.id.textViewObavestenje);

        Automobil podaci=(Automobil) getIntent().getSerializableExtra("AUTO");
        buttonServis.setOnClickListener(v -> {
            String datum=editTextDatum.getText().toString().trim();
            String km=editTextKilometraza.getText().toString().trim();
            String zamena=editTextZamena.getText().toString().trim();

            if (datum.isEmpty() || km.isEmpty()) {
                textViewObavestenje.setText("Unesite datum i kilometražu!");
            } else {
                // Pravimo opis servisa
                StringBuilder sb=new StringBuilder();
                sb.append("Datum: ").append(datum).append("\nKM: ").append(km);

                if (checkBoxMaliServis.isChecked()) sb.append("\n• Mali servis");
                if (checkBoxVelikiServis.isChecked()) sb.append("\n• Veliki servis");
                if (checkBoxKlima.isChecked()) sb.append("\n• Klima");
                if (checkBoxReglaza.isChecked()) sb.append("\n• Reglaža");
                if (checkBoxMenjac.isChecked()) sb.append("\n• Menjač");
                if (checkBoxVulkanizer.isChecked()) sb.append("\n• Vulkanizer");

                if (!zamena.isEmpty()) sb.append("\nZamena: ").append(zamena);

                String konacniOpis=sb.toString();

                new Thread(() -> {
                    AppDatabase db=AppDatabase.getDatabase(getApplicationContext());
                  // Koristimo podaci.id koje smo dobili preko Intenta
                    db.automobilDao().insertServis(new Service(podaci.id, konacniOpis));

                    runOnUiThread(() -> {
                      // Vraćamo se u Servise, podaci su sada u bazi
                        Intent intent=new Intent(Uradjeno.this, Servisi.class);
                        intent.putExtra("AUTO", podaci);
                        startActivity(intent);
                    });
                }).start();
            }
        });
    }
}
