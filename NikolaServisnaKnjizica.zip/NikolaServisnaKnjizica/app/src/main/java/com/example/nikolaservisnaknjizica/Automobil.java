package com.example.nikolaservisnaknjizica;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;
import java.util.ArrayList;
@Entity(tableName = "garaza")

public class Automobil implements java.io.Serializable {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String marka, model, godiste, karoserija, gorivo, sasija, kubikaza, km;
    public Automobil(String marka, String model, String godiste, String karoserija, String gorivo, String sasija, String kubikaza, String km) {
        this.marka = marka;
        this.model = model;
        this.godiste = godiste;
        this.karoserija = karoserija;
        this.gorivo = gorivo;
        this.sasija = sasija;
        this.kubikaza = kubikaza;
        this.km = km;
    }
}
