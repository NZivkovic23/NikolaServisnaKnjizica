package com.example.nikolaservisnaknjizica;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface AutomobilDao {
    @Insert
    void insertAuto(Automobil automobil);

    @Query("SELECT * FROM garaza")
    List<Automobil> getAllCars();

    @Insert
    void insertServis(Service servis);

    @Query("SELECT * FROM servisi_tabela WHERE autoId = :idAuta")
    List<Service> getServisiZaAuto(int idAuta);
}
