package com.example.nikolaservisnaknjizica;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class Garaza extends AppCompatActivity {
    private ListView listViewAuto;
    private List<Automobil> listaIzBaze;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_garaza);

        listViewAuto=findViewById(R.id.listViewAuto);
        Button buttonDodavanjeAuta=findViewById(R.id.buttonDodavanjeServisa);

        buttonDodavanjeAuta.setOnClickListener(v -> {
            startActivity(new Intent(Garaza.this, Podaci.class));
        });

        // KLIK NA AUTO (ITEM) - Ovde se šalju podaci u Servise
        listViewAuto.setOnItemClickListener((parent, view, position, id) -> {
            if (listaIzBaze != null && position < listaIzBaze.size()) {
                Automobil odabraniAuto = listaIzBaze.get(position);
                Intent intent=new Intent(Garaza.this, Servisi.class);
                intent.putExtra("AUTO", odabraniAuto); // Šaljemo ceo objekat sa ID-jem
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        osveziListu();
    }
    private void osveziListu() {
        new Thread(() -> {
            AppDatabase db=AppDatabase.getDatabase(getApplicationContext());
            listaIzBaze=db.automobilDao().getAllCars();

            ArrayList<String> prikazi=new ArrayList<>();
            for (Automobil a : listaIzBaze) {
                prikazi.add("🚗 " + a.marka + " " + a.model + " (" + a.godiste + ")");
            }

            runOnUiThread(() -> {
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1, prikazi);
                listViewAuto.setAdapter(adapter);
            });
        }).start();
    }
}